EEF Node — standalone node runtime.

Installed into its own directory (default C:/eefn) by bootstrap_eef.py, which
writes config.json (node_id, name, psk, ordered endpoints) here.

Run:  python run_node.py
Options:  --connect H:PORT,list   --name NAME   --id ID   --psk SECRET   --allow-write

Requires: Python 3.11+ and the `cryptography` package (installed by the bootstrap).
